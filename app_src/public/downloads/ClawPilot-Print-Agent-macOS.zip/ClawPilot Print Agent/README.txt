ClawPilot Print Agent for macOS
==================================

Version 0.1.0-preview.2

This download is the operator setup for ClawPilot's first-party raw-ZPL local
print service. It supports a network Zebra-compatible printer reachable by
hostname or IP on raw TCP port 9100. It does not support USB-only printers,
PDF/PNG, office documents, Windows, or arbitrary printer drivers.

Download first, then finish web setup
-------------------------------------

1. Download and extract this credential-free ZIP.
2. Open "ClawPilot Print Agent.command" and choose "Pair a workspace and
   printer" so the local endpoint prompts are ready.
3. In the ClawPilot web app, open Operations > Printing > Agents.
4. Create a short-lived pairing code for the exact workspace and warehouse.
5. Keep the code dialog open while pairing this Mac.

Install or pair
---------------

1. This preview requires Node.js 20 or newer from https://nodejs.org.
2. Extract the ZIP.
3. Double-click "ClawPilot Print Agent.command" (or Control-click and choose
   Open once if macOS blocks the unsigned preview).
4. Choose "Pair a workspace and printer".
5. Enter a unique workspace/printer instance name, the printer hostname or IP,
   and its raw port (normally 9100).
6. The helper tests raw endpoint reachability without printing or claiming a
   ClawPilot job.
7. Paste the short-lived cppair code only at the macOS Keychain prompt.

Do not disable Gatekeeper.

The helper redeems the short-lived pairing code over HTTPS and atomically
replaces it in macOS Keychain with the long-lived runtime credential. Neither
secret is put in the LaunchAgent property list, command arguments, logs, or
this download. Direct entry of a cpprint runtime credential exists only for
explicit legacy/manual compatibility and is not the normal web workflow. The
printer hostname or IP remains in the local LaunchAgent and is not sent to
ClawPilot's hosted printer-configuration API. The hosted service receives only
an opaque local device reference after acknowledged delivery.

Multiple workspaces may use the same physical printer. Pair each workspace's
web-enrolled agent as a separate, uniquely named local instance. Writes to the
same endpoint are serialized by an operating-system lock.

Test, stop, uninstall, or re-pair
---------------------------------

Open the same .command file again. Its menu can test LaunchAgent/runtime/
Keychain presence and raw printer reachability without printing a label or
claiming a job. Uninstall stops and removes only the selected LaunchAgent. It
intentionally preserves the Keychain item, device key, and delivery ledger so
lost acknowledgements or uncertain physical output cannot cause a duplicate.

For a new credential, revoke or rotate the prior web agent, uninstall its local
LaunchAgent, create a new short-lived pairing code, and pair a new unique
instance. Retained state is not silently deleted or reused.

Distribution status
-------------------

This macOS preview ZIP is not code-signed or notarized. It is not a .pkg or a
native .app and does not claim those release controls. A signed/notarized app
can replace this preview without changing ClawPilot's web enrollment,
credential, ledger, claim fencing, or device-privacy contracts.
