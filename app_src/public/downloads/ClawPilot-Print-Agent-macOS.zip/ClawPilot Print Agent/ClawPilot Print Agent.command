#!/bin/bash
set -u

AGENT_DOWNLOAD_DIR="$(cd "$(dirname "$0")" && pwd)"
NODE_EXECUTABLE=""
for CANDIDATE in /opt/homebrew/bin/node /usr/local/bin/node "$(command -v node 2>/dev/null || true)"; do
  if [ -n "$CANDIDATE" ] && [ -x "$CANDIDATE" ]; then
    NODE_EXECUTABLE="$CANDIDATE"
    break
  fi
done

if [ -z "$NODE_EXECUTABLE" ]; then
  echo "ClawPilot Print Agent requires Node.js 20 or newer on this Mac."
  echo "Install Node.js from https://nodejs.org, then open this file again."
  read -r -p "Press Return to close..."
  exit 1
fi

NODE_MAJOR="$($NODE_EXECUTABLE -p 'Number(process.versions.node.split(".")[0])')"
if [ "$NODE_MAJOR" -lt 20 ]; then
  echo "ClawPilot Print Agent requires Node.js 20 or newer."
  echo "This Mac is using Node.js $($NODE_EXECUTABLE --version)."
  read -r -p "Press Return to close..."
  exit 1
fi

"$NODE_EXECUTABLE" "$AGENT_DOWNLOAD_DIR/runtime/manage-macos-print-agent.mjs"
RESULT=$?
echo
read -r -p "Press Return to close..."
exit "$RESULT"
